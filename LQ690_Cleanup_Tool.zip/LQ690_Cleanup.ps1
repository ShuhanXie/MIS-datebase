﻿#requires -version 5.1
<#
EPSON LQ-690 Series Cleanup Tool
Purpose:
  Safely remove EPSON LQ-690 / LQ-690C / LQ-690CII printer objects and driver registrations.
  Creates backups and logs before making changes.

IMPORTANT:
  - Run as Administrator.
  - This tool intentionally DOES NOT delete arbitrary files from System32\spool\drivers.
  - It only targets names matching LQ-690 / LQ-690C / LQ-690CII.
  - EPSON SIDM 64Monitor removal is optional and requires confirmation.
#>

$ErrorActionPreference = "Continue"

function Test-IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdmin)) {
    Write-Host "此工具需要系統管理員權限。" -ForegroundColor Red
    Write-Host "請右鍵 Run_LQ690_Cleanup.bat -> 以系統管理員身分執行。"
    Read-Host "按 Enter 結束"
    exit 1
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$base = Join-Path $env:SystemDrive "LQ690_Cleanup"
$work = Join-Path $base $stamp
$log = Join-Path $work "cleanup.log"
$backup = Join-Path $work "backup"

New-Item -ItemType Directory -Force -Path $work,$backup | Out-Null

function Log([string]$msg) {
    $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg
    $line | Tee-Object -FilePath $log -Append
}

function Section([string]$name) {
    Write-Host ""
    Write-Host ("="*72) -ForegroundColor Cyan
    Write-Host $name -ForegroundColor Cyan
    Write-Host ("="*72) -ForegroundColor Cyan
    Log "=== $name ==="
}

Section "EPSON LQ-690 系列清除工具"
Write-Host "工作資料夾: $work"
Write-Host ""
Write-Host "本工具會處理：" -ForegroundColor Yellow
Write-Host "  - 名稱含 LQ-690 / LQ-690C / LQ-690CII 的印表機"
Write-Host "  - 名稱含 690 的 EPSON Printer Driver"
Write-Host "  - Version-3 登錄檔中名稱含 690 的 Driver 項目"
Write-Host "  - 列印佇列暫存"
Write-Host ""
Write-Host "不會自動刪除：" -ForegroundColor Green
Write-Host "  - 其他 EPSON 印表機驅動"
Write-Host "  - System32\spool\drivers 內的 DLL"
Write-Host "  - EPSON SIDM 64Monitor（除非你另外確認）"
Write-Host ""

$go = Read-Host "要開始掃描嗎？輸入 YES"
if ($go -ne "YES") {
    Log "User cancelled before scan."
    exit 0
}

Section "1. 備份 Print 登錄檔"
$regBackup = Join-Path $backup "Print_Backup.reg"
& reg.exe export "HKLM\SYSTEM\CurrentControlSet\Control\Print" $regBackup /y | Out-File -FilePath $log -Append
Log "Registry backup: $regBackup"

Section "2. 掃描 LQ-690 印表機物件"
$printers = @()
try {
    $printers = Get-Printer | Where-Object {
        $_.Name -match '(?i)LQ[\s\-_]*690|690C|690CII'
    }
} catch {
    Log "Get-Printer failed: $($_.Exception.Message)"
}

if ($printers.Count -gt 0) {
    $printers | Format-Table Name, DriverName, PortName -AutoSize
    $printers | Out-File (Join-Path $work "printers_before.txt")
} else {
    Write-Host "未找到名稱含 690 的印表機物件。"
}

Section "3. 掃描 LQ-690 Printer Driver"
$drivers = @()
try {
    $drivers = Get-PrinterDriver | Where-Object {
        ($_.Name -match '(?i)LQ[\s\-_]*690|690C|690CII') -and
        ($_.Name -match '(?i)EPSON|LQ')
    }
} catch {
    Log "Get-PrinterDriver failed: $($_.Exception.Message)"
}

if ($drivers.Count -gt 0) {
    $drivers | Format-Table Name, Manufacturer, MajorVersion -AutoSize
    $drivers | Out-File (Join-Path $work "drivers_before.txt")
} else {
    Write-Host "Get-PrinterDriver 未找到 LQ-690 系列 Driver。"
}

Section "4. 掃描 Version-3 登錄項目"
$v3 = "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Environments\Windows x64\Drivers\Version-3"
$reg690 = @()
if (Test-Path $v3) {
    $reg690 = Get-ChildItem $v3 | Where-Object {
        $_.PSChildName -match '(?i)LQ[\s\-_]*690|690C|690CII'
    }
}
if ($reg690.Count -gt 0) {
    $reg690 | Select-Object PSChildName | Format-Table -AutoSize
} else {
    Write-Host "Version-3 登錄檔中未找到 LQ-690 系列項目。"
}

Section "5. Driver Store EPSON 項目（僅列出，不自動刪除）"
$pnputilText = & pnputil.exe /enum-drivers 2>&1
$pnputilPath = Join-Path $work "pnputil_enum_drivers.txt"
$pnputilText | Out-File -Encoding utf8 $pnputilPath
Write-Host "已輸出完整清單到：$pnputilPath"
Write-Host "注意：Driver Store 的 INF 名稱不一定含 690，因此本工具不會猜測刪除 oemXX.inf。" -ForegroundColor Yellow

Section "6. 執行清除"
Write-Host "即將刪除上面找到的 LQ-690 系列印表機與 Driver。" -ForegroundColor Yellow
$confirm = Read-Host "確定執行？輸入 DELETE"
if ($confirm -ne "DELETE") {
    Log "User cancelled before deletion."
    Write-Host "已取消。"
    exit 0
}

# Remove printer objects first
foreach ($p in $printers) {
    try {
        Log "Removing printer: $($p.Name)"
        Remove-Printer -Name $p.Name -ErrorAction Stop
    } catch {
        Log "FAILED Remove-Printer [$($p.Name)]: $($_.Exception.Message)"
    }
}

# Stop spooler and clear queue
try {
    Log "Stopping spooler"
    Stop-Service Spooler -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
} catch {}

$queue = Join-Path $env:windir "System32\spool\PRINTERS"
if (Test-Path $queue) {
    Get-ChildItem $queue -Force -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            Log "Deleting spool file: $($_.FullName)"
            Remove-Item $_.FullName -Force -ErrorAction Stop
        } catch {
            Log "FAILED spool file delete: $($_.FullName) - $($_.Exception.Message)"
        }
    }
}

# Remove printer drivers using PrintManagement when possible
foreach ($d in $drivers) {
    try {
        Log "Removing printer driver: $($d.Name)"
        # Spooler needs to be running for Remove-PrinterDriver
        Start-Service Spooler -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 1
        Remove-PrinterDriver -Name $d.Name -ErrorAction Stop
    } catch {
        Log "FAILED Remove-PrinterDriver [$($d.Name)]: $($_.Exception.Message)"
    }
}

# Stop spooler again before registry cleanup
Stop-Service Spooler -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2

foreach ($r in $reg690) {
    try {
        $exportName = ($r.PSChildName -replace '[\\/:*?"<>|]', '_') + ".reg"
        $exportPath = Join-Path $backup $exportName
        $nativeKey = "HKLM\SYSTEM\CurrentControlSet\Control\Print\Environments\Windows x64\Drivers\Version-3\$($r.PSChildName)"
        & reg.exe export $nativeKey $exportPath /y | Out-File -FilePath $log -Append
        Log "Deleting registry driver key: $nativeKey"
        Remove-Item $r.PSPath -Recurse -Force -ErrorAction Stop
    } catch {
        Log "FAILED registry delete [$($r.PSChildName)]: $($_.Exception.Message)"
    }
}

Section "7. EPSON SIDM 64Monitor"
$sidmNative = "HKLM\SYSTEM\CurrentControlSet\Control\Print\Monitors\EPSON SIDM 64Monitor"
$sidmPs = "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Monitors\EPSON SIDM 64Monitor"

if (Test-Path $sidmPs) {
    Write-Host "偵測到：EPSON SIDM 64Monitor" -ForegroundColor Yellow
    Write-Host "如果這台還有其他 EPSON 點矩陣印表機，建議不要刪。" -ForegroundColor Yellow
    $sidm = Read-Host "確定要移除 EPSON SIDM 64Monitor？輸入 SIDM 才會刪除"
    if ($sidm -eq "SIDM") {
        $sidmBackup = Join-Path $backup "EPSON_SIDM_64Monitor.reg"
        & reg.exe export $sidmNative $sidmBackup /y | Out-File -FilePath $log -Append
        try {
            Remove-Item $sidmPs -Recurse -Force -ErrorAction Stop
            Log "Removed EPSON SIDM 64Monitor"
            Write-Host "已移除 EPSON SIDM 64Monitor。"
        } catch {
            Log "FAILED removing SIDM: $($_.Exception.Message)"
        }
    } else {
        Write-Host "保留 EPSON SIDM 64Monitor。"
        Log "SIDM monitor retained."
    }
} else {
    Write-Host "未偵測到 EPSON SIDM 64Monitor。"
}

Section "8. 啟動 Print Spooler"
try {
    Start-Service Spooler -ErrorAction Stop
    Start-Sleep -Seconds 5
} catch {
    Log "FAILED Start-Service Spooler: $($_.Exception.Message)"
}

$svc = Get-Service Spooler
Write-Host "Print Spooler 狀態：$($svc.Status)"
Log "Spooler status after cleanup: $($svc.Status)"

Section "9. 清除後檢查"
try {
    $leftPrinters = Get-Printer | Where-Object {$_.Name -match '(?i)LQ[\s\-_]*690|690C|690CII'}
    $leftDrivers = Get-PrinterDriver | Where-Object {$_.Name -match '(?i)LQ[\s\-_]*690|690C|690CII'}

    Write-Host "剩餘 690 印表機數量：$($leftPrinters.Count)"
    Write-Host "剩餘 690 Driver 數量：$($leftDrivers.Count)"

    if ($leftPrinters.Count -gt 0) {
        $leftPrinters | Format-Table Name,DriverName,PortName -AutoSize
    }
    if ($leftDrivers.Count -gt 0) {
        $leftDrivers | Format-Table Name,Manufacturer,MajorVersion -AutoSize
    }
} catch {}

Write-Host ""
Write-Host "完成。" -ForegroundColor Green
Write-Host "Log：$log"
Write-Host "Backup：$backup"
Write-Host ""
Write-Host "建議下一步：" -ForegroundColor Cyan
Write-Host "1. 重新開機"
Write-Host "2. 確認 Print Spooler 維持 Running"
Write-Host "3. 再測試 PS531 安裝 LQ-690CII"
Write-Host ""
Read-Host "按 Enter 結束"
