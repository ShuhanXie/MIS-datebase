﻿# EPSON LQ-690 Cleanup Tool

用途：清除 Windows 上 LQ-690 / LQ-690C / LQ-690CII 相關的印表機物件與驅動註冊。

## 使用方式

1. 解壓縮 ZIP。
2. 右鍵 `Run_LQ690_Cleanup.bat`
3. 選擇「以系統管理員身分執行」。
4. 第一次輸入 `YES` 只會開始掃描。
5. 確認畫面列出的項目後，輸入 `DELETE` 才會真正刪除。
6. 若偵測到 `EPSON SIDM 64Monitor`，只有輸入 `SIDM` 才會刪除。

## 安全設計

- 執行前自動備份 `HKLM\SYSTEM\CurrentControlSet\Control\Print`。
- 所有紀錄存到 `C:\LQ690_Cleanup\<日期時間>\`。
- 不會自動刪除 `C:\Windows\System32\spool\drivers` 裡的 DLL。
- 不會猜測刪除 Driver Store 的 `oemXX.inf`。
- 不會刪除其他名稱不含 690 的 EPSON 印表機 Driver。
- EPSON SIDM 64Monitor 預設保留，需另外確認。

## 建議

清除完成後重新開機，先確認 Print Spooler 維持 Running，再測試 PS531 安裝 LQ-690CII。
