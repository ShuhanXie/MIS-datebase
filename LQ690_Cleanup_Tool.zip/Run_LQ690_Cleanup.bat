﻿@echo off
chcp 65001 >nul
title EPSON LQ-690 Cleanup Tool
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0LQ690_Cleanup.ps1"
