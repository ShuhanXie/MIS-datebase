﻿PC Diagnostic Debug v4
======================

壓縮檔內包含：
- Run_Diagnostic.cmd
- PC_Diagnostic_NoEvent.ps1
- README.txt

使用方法：
1. 完整解壓縮。
2. 建議放到 C:\PC_Diagnostic，避免 OneDrive 或過長路徑影響。
3. 在 Run_Diagnostic.cmd 上按右鍵，選擇「以系統管理員身分執行」。
4. 執行時會顯示 [1/9] 至 [9/9] 的進度。
5. 若失敗，請提供 PC_Diagnostic_RunLog.txt。

本版已修正 CMD 使用 UTF-8 BOM，造成 @echo off 失效、每行指令都顯示的問題。
