﻿#requires -version 5.1
<#
電腦環境檢測與報告工具
功能：
- 收集電腦基本資料
- Windows / BIOS / CPU / RAM
- 磁碟與分割區
- 網路設定
- 印表機與連接埠
- 防毒狀態
- 重要服務
- 輸出 HTML、CSV、TXT

本工具預設只讀取資訊，不修改系統設定。
建議以系統管理員身分執行，以取得較完整資料。
#>

[CmdletBinding()]
param(
    [string]$OutputRoot = "$env:USERPROFILE\Desktop\PC_Diagnostic_Reports"
)

$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"

function HtmlEncode {
    param([AllowNull()][object]$Value)
    if ($null -eq $Value) { return "" }
    return [System.Net.WebUtility]::HtmlEncode([string]$Value)
}

function ConvertTo-HtmlTable {
    param(
        [Parameter(Mandatory)]
        [array]$Data,
        [string]$EmptyMessage = "無資料"
    )

    if (-not $Data -or $Data.Count -eq 0) {
        return "<p class='empty'>$EmptyMessage</p>"
    }

    $properties = @($Data[0].PSObject.Properties.Name)
    $html = "<table><thead><tr>"
    foreach ($property in $properties) {
        $html += "<th>$(HtmlEncode $property)</th>"
    }
    $html += "</tr></thead><tbody>"

    foreach ($row in $Data) {
        $html += "<tr>"
        foreach ($property in $properties) {
            $value = $row.$property
            if ($value -is [array]) { $value = $value -join ", " }
            $html += "<td>$(HtmlEncode $value)</td>"
        }
        $html += "</tr>"
    }

    $html += "</tbody></table>"
    return $html
}

function Get-RegistryValueSafe {
    param(
        [string]$Path,
        [string]$Name
    )
    try {
        return (Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop).$Name
    }
    catch {
        return $null
    }
}

function Format-Bytes {
    param([double]$Bytes)
    if ($Bytes -ge 1TB) { return "{0:N2} TB" -f ($Bytes / 1TB) }
    if ($Bytes -ge 1GB) { return "{0:N2} GB" -f ($Bytes / 1GB) }
    if ($Bytes -ge 1MB) { return "{0:N2} MB" -f ($Bytes / 1MB) }
    return "{0:N0} Bytes" -f $Bytes
}

$computerName = $env:COMPUTERNAME
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$reportFolder = Join-Path $OutputRoot "${computerName}_$timestamp"
New-Item -Path $reportFolder -ItemType Directory -Force | Out-Null

$htmlPath = Join-Path $reportFolder "${computerName}_環境檢測報告.html"
$summaryCsvPath = Join-Path $reportFolder "${computerName}_摘要.csv"
$softwareCsvPath = Join-Path $reportFolder "${computerName}_已安裝軟體.csv"
$networkCsvPath = Join-Path $reportFolder "${computerName}_網路設定.csv"
$printerCsvPath = Join-Path $reportFolder "${computerName}_印表機.csv"
$rawTextPath = Join-Path $reportFolder "${computerName}_原始診斷資料.txt"

Write-Host "正在收集電腦環境資料..." -ForegroundColor Cyan

Write-Host "[1/9] 收集 Windows 與硬體基本資料..." -ForegroundColor Cyan

# 基本系統資料
$cs = Get-CimInstance Win32_ComputerSystem
$os = Get-CimInstance Win32_OperatingSystem
$bios = Get-CimInstance Win32_BIOS
$baseboard = Get-CimInstance Win32_BaseBoard
$cpuList = Get-CimInstance Win32_Processor
$gpuList = Get-CimInstance Win32_VideoController
$ramModules = Get-CimInstance Win32_PhysicalMemory

$windowsDisplayVersion = Get-RegistryValueSafe `
    -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" `
    -Name "DisplayVersion"

$windowsReleaseId = Get-RegistryValueSafe `
    -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" `
    -Name "ReleaseId"

# Windows 名稱優先使用 Win32_OperatingSystem.Caption。
# 部分 Windows 11 電腦的登錄檔 ProductName 仍可能回報 Windows 10，
# 因此再依組建編號（Windows 11 為 22000 以上）進行校正。
$windowsProductName = $os.Caption
if ([string]::IsNullOrWhiteSpace($windowsProductName)) {
    $windowsProductName = Get-RegistryValueSafe `
        -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" `
        -Name "ProductName"
}

if ([int]$os.BuildNumber -ge 22000 -and $windowsProductName -match "Windows 10") {
    $windowsProductName = $windowsProductName -replace "Windows 10", "Windows 11"
}

$windowsUbr = Get-RegistryValueSafe `
    -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" `
    -Name "UBR"

$activationStatus = "無法判斷"
$license = Get-CimInstance SoftwareLicensingProduct |
    Where-Object {
        $_.PartialProductKey -and $_.Name -like "Windows*"
    } |
    Select-Object -First 1

if ($license) {
    $activationStatus = switch ($license.LicenseStatus) {
        0 { "未授權" }
        1 { "已啟用" }
        2 { "初始寬限期" }
        3 { "額外寬限期" }
        4 { "非正版寬限期" }
        5 { "通知模式" }
        6 { "延長寬限期" }
        default { "未知" }
    }
}

$systemInfo = [PSCustomObject]@{
    "檢測時間"       = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "電腦名稱"       = $computerName
    "登入使用者"     = "$env:USERDOMAIN\$env:USERNAME"
    "製造商"         = $cs.Manufacturer
    "型號"           = $cs.Model
    "序號"           = $bios.SerialNumber
    "網域/工作群組"  = if ($cs.PartOfDomain) { $cs.Domain } else { $cs.Workgroup }
    "Windows版本"    = "$windowsProductName $windowsDisplayVersion"
    "OS組建"         = if ($windowsUbr -ne $null) { "$($os.BuildNumber).$windowsUbr" } else { $os.BuildNumber }
    "系統架構"       = $os.OSArchitecture
    "啟用狀態"       = $activationStatus
    "最後開機時間"   = $os.LastBootUpTime
    "開機經過時間"   = (New-TimeSpan -Start $os.LastBootUpTime -End (Get-Date)).ToString()
    "BIOS版本"       = ($bios.SMBIOSBIOSVersion -join ", ")
    "BIOS日期"       = $bios.ReleaseDate
    "主機板"         = "$($baseboard.Manufacturer) $($baseboard.Product)"
    "總記憶體"       = Format-Bytes $cs.TotalPhysicalMemory
}

$cpuInfo = foreach ($cpu in $cpuList) {
    [PSCustomObject]@{
        "名稱"       = $cpu.Name.Trim()
        "核心數"     = $cpu.NumberOfCores
        "執行緒數"   = $cpu.NumberOfLogicalProcessors
        "目前時脈MHz"= $cpu.CurrentClockSpeed
        "最大時脈MHz"= $cpu.MaxClockSpeed
    }
}

$memoryInfo = foreach ($ram in $ramModules) {
    [PSCustomObject]@{
        "插槽"       = $ram.DeviceLocator
        "容量"       = Format-Bytes $ram.Capacity
        "速度MHz"    = $ram.Speed
        "製造商"     = $ram.Manufacturer
        "料號"       = $ram.PartNumber.Trim()
        "序號"       = $ram.SerialNumber
    }
}

$gpuInfo = foreach ($gpu in $gpuList) {
    [PSCustomObject]@{
        "名稱"       = $gpu.Name
        "驅動版本"   = $gpu.DriverVersion
        "顯示記憶體" = if ($gpu.AdapterRAM) { Format-Bytes $gpu.AdapterRAM } else { "無法判斷" }
        "解析度"     = if ($gpu.CurrentHorizontalResolution) {
            "$($gpu.CurrentHorizontalResolution)x$($gpu.CurrentVerticalResolution)"
        } else {
            "未取得"
        }
    }
}

Write-Host "[2/9] 收集磁碟與分割區資料..." -ForegroundColor Cyan

# 磁碟
$physicalDisks = @()
try {
    $physicalDisks = Get-PhysicalDisk | ForEach-Object {
        [PSCustomObject]@{
            "FriendlyName" = $_.FriendlyName
            "SerialNumber" = $_.SerialNumber
            "MediaType"    = $_.MediaType
            "BusType"      = $_.BusType
            "Size"         = Format-Bytes $_.Size
            "HealthStatus" = $_.HealthStatus
            "OperationalStatus" = ($_.OperationalStatus -join ", ")
        }
    }
}
catch {
    $physicalDisks = Get-CimInstance Win32_DiskDrive | ForEach-Object {
        [PSCustomObject]@{
            "FriendlyName" = $_.Model
            "SerialNumber" = $_.SerialNumber
            "MediaType"    = $_.MediaType
            "BusType"      = $_.InterfaceType
            "Size"         = Format-Bytes $_.Size
            "HealthStatus" = $_.Status
            "OperationalStatus" = $_.Status
        }
    }
}

$volumes = Get-CimInstance Win32_LogicalDisk | ForEach-Object {
    $freePercent = if ($_.Size -gt 0) {
        [math]::Round(($_.FreeSpace / $_.Size) * 100, 1)
    } else {
        $null
    }

    [PSCustomObject]@{
        "磁碟機"     = $_.DeviceID
        "名稱"       = $_.VolumeName
        "檔案系統"   = $_.FileSystem
        "總容量"     = if ($_.Size) { Format-Bytes $_.Size } else { "" }
        "可用空間"   = if ($_.FreeSpace) { Format-Bytes $_.FreeSpace } else { "" }
        "可用百分比" = if ($freePercent -ne $null) { "$freePercent%" } else { "" }
        "類型"       = switch ($_.DriveType) {
            2 { "卸除式磁碟" }
            3 { "本機磁碟" }
            4 { "網路磁碟" }
            5 { "光碟機" }
            default { "其他" }
        }
    }
}

Write-Host "[3/9] 收集網路設定..." -ForegroundColor Cyan

# 網路
$networkInfo = @()
$netConfigs = Get-CimInstance Win32_NetworkAdapterConfiguration |
    Where-Object { $_.IPEnabled }

foreach ($net in $netConfigs) {
    $adapter = Get-CimInstance Win32_NetworkAdapter |
        Where-Object { $_.Index -eq $net.Index } |
        Select-Object -First 1

    $networkInfo += [PSCustomObject]@{
        "網卡名稱"   = $net.Description
        "MAC位址"    = $net.MACAddress
        "DHCP啟用"   = $net.DHCPEnabled
        "IPv4/IPv6"  = ($net.IPAddress -join ", ")
        "子網路遮罩" = ($net.IPSubnet -join ", ")
        "預設閘道"   = ($net.DefaultIPGateway -join ", ")
        "DNS伺服器"  = ($net.DNSServerSearchOrder -join ", ")
        "DHCP伺服器" = $net.DHCPServer
        "連線狀態"   = if ($adapter.NetConnectionStatus -eq 2) { "已連線" } else { "未連線/未知" }
        "速度"       = if ($adapter.Speed) { Format-Bytes $adapter.Speed } else { "未知" }
    }
}

Write-Host "[4/9] 執行網路測試..." -ForegroundColor Cyan

# 網路測試
$gateway = ($netConfigs.DefaultIPGateway | Where-Object { $_ } | Select-Object -First 1)
$dnsServer = ($netConfigs.DNSServerSearchOrder | Where-Object { $_ } | Select-Object -First 1)

function Test-PingSafe {
    param([string]$Target)
    if (-not $Target) { return "未設定" }
    try {
        if (Test-Connection -ComputerName $Target -Count 1 -Quiet -ErrorAction Stop) {
            return "成功"
        }
        return "失敗"
    }
    catch {
        return "失敗"
    }
}

$networkTests = @(
    [PSCustomObject]@{
        "測試項目" = "預設閘道 Ping"
        "目標"     = $gateway
        "結果"     = Test-PingSafe $gateway
    },
    [PSCustomObject]@{
        "測試項目" = "DNS伺服器 Ping"
        "目標"     = $dnsServer
        "結果"     = Test-PingSafe $dnsServer
    },
    [PSCustomObject]@{
        "測試項目" = "外部IP連線"
        "目標"     = "1.1.1.1"
        "結果"     = Test-PingSafe "1.1.1.1"
    }
)

$dnsResolveResult = try {
    Resolve-DnsName -Name "www.microsoft.com" -ErrorAction Stop | Out-Null
    "成功"
}
catch {
    "失敗"
}

$networkTests += [PSCustomObject]@{
    "測試項目" = "DNS名稱解析"
    "目標"     = "www.microsoft.com"
    "結果"     = $dnsResolveResult
}

Write-Host "[5/9] 收集印表機資料..." -ForegroundColor Cyan

# 印表機
$printers = Get-CimInstance Win32_Printer | ForEach-Object {
    [PSCustomObject]@{
        "名稱"       = $_.Name
        "驅動程式"   = $_.DriverName
        "連接埠"     = $_.PortName
        "預設印表機" = $_.Default
        "共用"       = $_.Shared
        "共用名稱"   = $_.ShareName
        "網路印表機" = $_.Network
        "離線"       = $_.WorkOffline
        "狀態"       = $_.PrinterStatus
    }
}

$printerPorts = Get-CimInstance Win32_TCPIPPrinterPort | ForEach-Object {
    [PSCustomObject]@{
        "連接埠名稱" = $_.Name
        "主機位址"   = $_.HostAddress
        "Port"       = $_.PortNumber
        "Protocol"   = if ($_.Protocol -eq 1) { "RAW" } elseif ($_.Protocol -eq 2) { "LPR" } else { $_.Protocol }
        "SNMP啟用"   = $_.SNMPEnabled
        "SNMP社群"   = $_.SNMPCommunity
    }
}

Write-Host "[6/9] 收集防毒與安全性資料..." -ForegroundColor Cyan

# 防毒
$antivirusInfo = @()
try {
    $antivirusInfo = Get-CimInstance -Namespace "root\SecurityCenter2" -ClassName AntivirusProduct |
        ForEach-Object {
            $stateHex = "{0:X6}" -f $_.productState
            [PSCustomObject]@{
                "產品名稱" = $_.displayName
                "執行檔"   = $_.pathToSignedProductExe
                "產品狀態" = $_.productState
                "狀態碼"   = $stateHex
            }
        }
}
catch {
    $antivirusInfo = @([PSCustomObject]@{
        "產品名稱" = "無法取得"
        "執行檔"   = ""
        "產品狀態" = ""
        "狀態碼"   = ""
    })
}

Write-Host "[7/9] 檢查重要服務..." -ForegroundColor Cyan

# 重要服務
$serviceNames = @(
    "Spooler",
    "wuauserv",
    "BITS",
    "Winmgmt",
    "Dnscache",
    "Dhcp",
    "LanmanServer",
    "LanmanWorkstation",
    "TermService",
    "WSearch"
)

$services = foreach ($serviceName in $serviceNames) {
    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($service) {
        $startMode = (Get-CimInstance Win32_Service -Filter "Name='$serviceName'").StartMode
        [PSCustomObject]@{
            "服務名稱" = $service.DisplayName
            "系統名稱" = $service.Name
            "狀態"     = $service.Status
            "啟動類型" = $startMode
        }
    }
}

Write-Host "[8/9] 收集已安裝軟體與更新..." -ForegroundColor Cyan

# 已安裝軟體
$softwarePaths = @(
    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
)

$software = Get-ItemProperty $softwarePaths |
    Where-Object { $_.DisplayName } |
    Select-Object @{
        Name = "軟體名稱"; Expression = { $_.DisplayName }
    }, @{
        Name = "版本"; Expression = { $_.DisplayVersion }
    }, @{
        Name = "發行者"; Expression = { $_.Publisher }
    }, @{
        Name = "安裝日期"; Expression = { $_.InstallDate }
    } |
    Sort-Object 軟體名稱 -Unique

# Windows Update 最近安裝紀錄
$hotfixes = Get-HotFix |
    Sort-Object InstalledOn -Descending |
    Select-Object -First 20 @{
        Name = "KB"; Expression = { $_.HotFixID }
    }, @{
        Name = "說明"; Expression = { $_.Description }
    }, @{
        Name = "安裝日期"; Expression = { $_.InstalledOn }
    }

# 問題摘要
$findings = New-Object System.Collections.Generic.List[object]

foreach ($volume in $volumes) {
    if ($volume."可用百分比" -match "([\d\.]+)%") {
        $percent = [double]$Matches[1]
        if ($percent -lt 10) {
            $findings.Add([PSCustomObject]@{
                "嚴重度" = "警告"
                "項目"   = "磁碟空間不足"
                "說明"   = "$($volume.'磁碟機') 僅剩 $($volume.'可用百分比') 可用空間"
            })
        }
    }
}

foreach ($disk in $physicalDisks) {
    if ($disk.HealthStatus -and $disk.HealthStatus -notin @("Healthy", "正常", "OK")) {
        $findings.Add([PSCustomObject]@{
            "嚴重度" = "警告"
            "項目"   = "磁碟健康狀態"
            "說明"   = "$($disk.FriendlyName)：$($disk.HealthStatus)"
        })
    }
}

if ($activationStatus -ne "已啟用") {
    $findings.Add([PSCustomObject]@{
        "嚴重度" = "注意"
        "項目"   = "Windows 啟用"
        "說明"   = "目前狀態：$activationStatus"
    })
}

if (($networkTests | Where-Object { $_."測試項目" -eq "預設閘道 Ping" }).結果 -eq "失敗") {
    $findings.Add([PSCustomObject]@{
        "嚴重度" = "警告"
        "項目"   = "閘道連線"
        "說明"   = "無法 Ping 預設閘道 $gateway"
    })
}

if ($dnsResolveResult -eq "失敗") {
    $findings.Add([PSCustomObject]@{
        "嚴重度" = "警告"
        "項目"   = "DNS 名稱解析"
        "說明"   = "無法解析 www.microsoft.com"
    })
}

$spooler = $services | Where-Object { $_."系統名稱" -eq "Spooler" }
if ($spooler -and $spooler."狀態" -ne "Running") {
    $findings.Add([PSCustomObject]@{
        "嚴重度" = "警告"
        "項目"   = "列印服務"
        "說明"   = "Print Spooler 目前狀態：$($spooler.'狀態')"
    })
}

if ($findings.Count -eq 0) {
    $findings.Add([PSCustomObject]@{
        "嚴重度" = "正常"
        "項目"   = "初步檢測"
        "說明"   = "未發現明顯異常；仍需依客戶實際症狀進一步判斷。"
    })
}

Write-Host "[9/9] 產生 HTML、CSV 與文字報告..." -ForegroundColor Cyan

# 輸出 CSV
@($systemInfo) | Export-Csv -Path $summaryCsvPath -NoTypeInformation -Encoding UTF8
$software | Export-Csv -Path $softwareCsvPath -NoTypeInformation -Encoding UTF8
$networkInfo | Export-Csv -Path $networkCsvPath -NoTypeInformation -Encoding UTF8
$printers | Export-Csv -Path $printerCsvPath -NoTypeInformation -Encoding UTF8

# 原始文字診斷資料
$rawText = @"
========================================
電腦環境檢測原始資料
========================================
檢測時間：$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
電腦名稱：$computerName

===== IPCONFIG /ALL =====
$(ipconfig /all | Out-String)

===== ROUTE PRINT =====
$(route print | Out-String)

===== ARP -A =====
$(arp -a | Out-String)

===== SYSTEMINFO =====
$(systeminfo | Out-String)

===== DRIVERQUERY =====
$(driverquery /v | Out-String)

===== NET USE =====
$(net use | Out-String)

===== GPRESULT =====
$(gpresult /r | Out-String)
"@

$rawText | Out-File -FilePath $rawTextPath -Encoding UTF8

# HTML 報告
$style = @"
<style>
body {
    font-family: "Microsoft JhengHei", "Segoe UI", sans-serif;
    margin: 24px;
    color: #222;
    background: #f5f7fa;
}
.container {
    max-width: 1400px;
    margin: auto;
}
.header {
    background: #ffffff;
    padding: 22px;
    border-radius: 10px;
    margin-bottom: 18px;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
}
.section {
    background: #ffffff;
    padding: 18px;
    border-radius: 10px;
    margin-bottom: 18px;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
}
h1 { margin: 0 0 8px 0; }
h2 { border-left: 5px solid #3b82f6; padding-left: 10px; }
table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
}
th, td {
    border: 1px solid #d8dee8;
    padding: 8px;
    text-align: left;
    vertical-align: top;
    word-break: break-word;
}
th {
    background: #eef3f8;
}
tr:nth-child(even) {
    background: #fafbfc;
}
.empty {
    color: #777;
    font-style: italic;
}
.note {
    color: #555;
    font-size: 13px;
}
</style>
"@

$html = @"
<!DOCTYPE html>
<html lang="zh-Hant">
<head>
<meta charset="UTF-8">
<title>$computerName 電腦環境檢測報告</title>
$style
</head>
<body>
<div class="container">
<div class="header">
<h1>電腦環境檢測報告</h1>
<p>電腦名稱：$(HtmlEncode $computerName)</p>
<p>檢測時間：$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")</p>
<p class="note">本報告為自動化初步檢測，不取代工程師現場判斷。</p>
</div>

<div class="section">
<h2>初步檢測結果</h2>
$(ConvertTo-HtmlTable -Data @($findings))
</div>

<div class="section">
<h2>系統摘要</h2>
$(ConvertTo-HtmlTable -Data @($systemInfo))
</div>

<div class="section">
<h2>處理器</h2>
$(ConvertTo-HtmlTable -Data @($cpuInfo))
</div>

<div class="section">
<h2>記憶體</h2>
$(ConvertTo-HtmlTable -Data @($memoryInfo))
</div>

<div class="section">
<h2>顯示卡</h2>
$(ConvertTo-HtmlTable -Data @($gpuInfo))
</div>

<div class="section">
<h2>實體磁碟</h2>
$(ConvertTo-HtmlTable -Data @($physicalDisks))
</div>

<div class="section">
<h2>磁碟分割區</h2>
$(ConvertTo-HtmlTable -Data @($volumes))
</div>

<div class="section">
<h2>網路設定</h2>
$(ConvertTo-HtmlTable -Data @($networkInfo))
</div>

<div class="section">
<h2>網路測試</h2>
$(ConvertTo-HtmlTable -Data @($networkTests))
</div>

<div class="section">
<h2>印表機</h2>
$(ConvertTo-HtmlTable -Data @($printers))
</div>

<div class="section">
<h2>TCP/IP 印表機連接埠</h2>
$(ConvertTo-HtmlTable -Data @($printerPorts))
</div>

<div class="section">
<h2>防毒軟體</h2>
$(ConvertTo-HtmlTable -Data @($antivirusInfo))
</div>

<div class="section">
<h2>重要服務</h2>
$(ConvertTo-HtmlTable -Data @($services))
</div>

<div class="section">
<h2>最近安裝的 Windows 更新</h2>
$(ConvertTo-HtmlTable -Data @($hotfixes))
</div>


<div class="section">
<h2>已安裝軟體</h2>
$(ConvertTo-HtmlTable -Data @($software))
</div>

</div>
</body>
</html>
"@

$html | Out-File -FilePath $htmlPath -Encoding UTF8

Write-Host ""
Write-Host "檢測完成。" -ForegroundColor Green
Write-Host "報告資料夾：$reportFolder" -ForegroundColor Yellow
Write-Host "HTML 報告：$htmlPath" -ForegroundColor Yellow

try {
    Start-Process $htmlPath
}
catch {
    Write-Host "無法自動開啟報告，請手動開啟 HTML 檔案。"
}
