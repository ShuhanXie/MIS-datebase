@echo off
setlocal EnableExtensions
chcp 65001 >nul
title PC Diagnostic Tool

pushd "%~dp0"

set "SCRIPT=%CD%\PC_Diagnostic_NoEvent.ps1"
set "LOG=%CD%\PC_Diagnostic_RunLog.txt"

> "%LOG%" echo ==================================================
>>"%LOG%" echo PC Diagnostic Run Log
>>"%LOG%" echo Start Time: %date% %time%
>>"%LOG%" echo Computer: %COMPUTERNAME%
>>"%LOG%" echo User: %USERDOMAIN%\%USERNAME%
>>"%LOG%" echo Script: %SCRIPT%
>>"%LOG%" echo ==================================================
>>"%LOG%" echo.

if not exist "%SCRIPT%" (
    echo [ERROR] Cannot find PC_Diagnostic_NoEvent.ps1
    >>"%LOG%" echo [ERROR] Script file not found.
    echo.
    pause
    popd
    exit /b 2
)

where powershell.exe >nul 2>&1
if errorlevel 1 (
    echo [ERROR] powershell.exe was not found.
    >>"%LOG%" echo [ERROR] powershell.exe was not found.
    echo.
    pause
    popd
    exit /b 3
)

echo ================================================
echo PC Diagnostic Tool
echo ================================================
echo.
echo The scan may take several minutes.
echo Do not close this window.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" 2>&1 | powershell.exe -NoLogo -NoProfile -Command "$input | Tee-Object -FilePath '%LOG%' -Append"
set "EXITCODE=%ERRORLEVEL%"

>>"%LOG%" echo.
>>"%LOG%" echo ==================================================
>>"%LOG%" echo Exit Code: %EXITCODE%
>>"%LOG%" echo End Time: %date% %time%
>>"%LOG%" echo ==================================================

echo.
echo ================================================
if "%EXITCODE%"=="0" (
    echo Diagnostic finished.
) else (
    echo Diagnostic ended with error code: %EXITCODE%
)
echo Log file:
echo %LOG%
echo ================================================
echo.
pause

popd
exit /b %EXITCODE%
