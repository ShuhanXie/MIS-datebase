[CmdletBinding()]
param(
    [string]$EndOfDayTaskName = 'UPS WorldShip End of Day',
    [int]$RetryShutdownDelayMinutes = 30,
    [int]$NormalShutdownDelaySeconds = 60,
    [switch]$NoShutdown
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$logDirectory = Join-Path $PSScriptRoot 'Logs'
$logFile = Join-Path $logDirectory ("ShutdownCheck-{0}.log" -f (Get-Date -Format 'yyyy-MM'))
New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null

function Write-Log {
    param([string]$Message)
    $line = '{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Add-Content -LiteralPath $logFile -Value $line -Encoding UTF8
    Write-Host $line
}

function Get-WorldShipProcesses {
    @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -match 'WorldShip' -or $_.MainWindowTitle -match 'WorldShip'
    })
}

try {
    Write-Log 'Checking whether UPS WorldShip is running.'
    $worldShipProcesses = Get-WorldShipProcesses

    if ($worldShipProcesses.Count -eq 0) {
        Write-Log 'WorldShip is not running. Normal shutdown condition met.'
        if ($NoShutdown) {
            Write-Log 'Test mode: immediate shutdown request skipped.'
            exit 0
        }

        & "$env:SystemRoot\System32\shutdown.exe" /s /t $NormalShutdownDelaySeconds /c "UPS WorldShip is closed. Automatic shutdown pending."
        if ($LASTEXITCODE -ne 0) {
            throw "shutdown.exe returned exit code $LASTEXITCODE."
        }
        Write-Log ("Windows shutdown requested with a {0}-second delay." -f $NormalShutdownDelaySeconds)
        exit 0
    }

    $processIds = ($worldShipProcesses | ForEach-Object { $_.Id }) -join ', '
    Write-Log ("WorldShip is still running. PID(s): {0}" -f $processIds)
    Write-Log ("Starting scheduled task: {0}" -f $EndOfDayTaskName)

    & "$env:SystemRoot\System32\schtasks.exe" /Run /TN $EndOfDayTaskName | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "Could not start scheduled task '$EndOfDayTaskName'. schtasks.exe returned exit code $LASTEXITCODE."
    }

    $delaySeconds = $RetryShutdownDelayMinutes * 60
    if ($NoShutdown) {
        Write-Log ("Test mode: task started, but the {0}-minute shutdown request was skipped." -f $RetryShutdownDelayMinutes)
        exit 0
    }

    & "$env:SystemRoot\System32\shutdown.exe" /s /t $delaySeconds /c "UPS WorldShip was still running. End of Day was requested; automatic shutdown will follow."
    if ($LASTEXITCODE -ne 0) {
        throw "shutdown.exe returned exit code $LASTEXITCODE."
    }
    Write-Log ("End of Day task started. Windows shutdown requested in {0} minutes." -f $RetryShutdownDelayMinutes)
    exit 0
}
catch {
    Write-Log ("FAILED: {0}" -f $_.Exception.Message)
    Write-Log 'No new shutdown request was created after the failure.'
    exit 1
}
