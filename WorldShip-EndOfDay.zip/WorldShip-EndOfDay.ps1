[CmdletBinding()]
param(
    [int]$DialogTimeoutSeconds = 30,
    [int]$WorldShipExitTimeoutMinutes = 30
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$logDirectory = Join-Path $PSScriptRoot 'Logs'
$logFile = Join-Path $logDirectory ("WorldShip-{0}.log" -f (Get-Date -Format 'yyyy-MM'))
New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null

function Write-Log {
    param([string]$Message)
    $line = '{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Add-Content -LiteralPath $logFile -Value $line -Encoding UTF8
    Write-Host $line
}

function Get-WorldShipProcesses {
    @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.MainWindowHandle -ne [IntPtr]::Zero -and
        ($_.MainWindowTitle -match 'WorldShip' -or $_.ProcessName -match 'WorldShip')
    })
}

function Find-DailySummaryButton {
    param(
        [System.Windows.Automation.AutomationElement]$Root,
        [int]$ProcessId
    )

    # Build the Chinese labels from Unicode code points so this script stays
    # ASCII-compatible with Windows PowerShell 5.1 on every system locale.
    $dailySummary = -join ([char[]](0x6BCF, 0x65E5, 0x7E3D, 0x7D50))
    $endOfDay = -join ([char[]](0x65E5, 0x7D42))
    $buttonNamePattern = [regex]::Escape($dailySummary) + '|' +
        [regex]::Escape($endOfDay) + '|End\s*of\s*Day'

    $buttons = $Root.FindAll(
        [System.Windows.Automation.TreeScope]::Descendants,
        (New-Object System.Windows.Automation.PropertyCondition(
            [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
            [System.Windows.Automation.ControlType]::Button
        ))
    )

    foreach ($button in $buttons) {
        $name = $button.Current.Name
        if ($button.Current.ProcessId -eq $ProcessId -and $name -match $buttonNamePattern) {
            return $button
        }
    }
    return $null
}

try {
    Write-Log 'Starting WorldShip End of Day workflow.'

    Add-Type -AssemblyName UIAutomationClient
    Add-Type -AssemblyName UIAutomationTypes

    $worldShip = Get-WorldShipProcesses | Select-Object -First 1
    if (-not $worldShip) {
        throw 'No open UPS WorldShip window was found.'
    }

    Write-Log ("Found WorldShip: PID={0}; Window={1}" -f $worldShip.Id, $worldShip.MainWindowTitle)

    if (-not $worldShip.CloseMainWindow()) {
        throw 'Could not request a normal close of the WorldShip window.'
    }
    Write-Log 'Close requested. Waiting for the End of Day confirmation dialog.'

    $dialogDeadline = (Get-Date).AddSeconds($DialogTimeoutSeconds)
    $summaryButton = $null
    while ((Get-Date) -lt $dialogDeadline -and -not $summaryButton) {
        Start-Sleep -Milliseconds 500
        $desktop = [System.Windows.Automation.AutomationElement]::RootElement
        $summaryButton = Find-DailySummaryButton -Root $desktop -ProcessId $worldShip.Id
    }

    if (-not $summaryButton) {
        throw "The End of Day button was not found within $DialogTimeoutSeconds seconds."
    }

    Write-Log ("Found button '{0}'. Invoking it now." -f $summaryButton.Current.Name)
    $invokePattern = $summaryButton.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
    $invokePattern.Invoke()
    Write-Log 'End of Day invoked. Waiting for upload and WorldShip exit.'

    $exitDeadline = (Get-Date).AddMinutes($WorldShipExitTimeoutMinutes)
    do {
        Start-Sleep -Seconds 2
        $stillRunning = @(Get-Process -Id $worldShip.Id -ErrorAction SilentlyContinue).Count -gt 0
    } while ($stillRunning -and (Get-Date) -lt $exitDeadline)

    if ($stillRunning) {
        throw "WorldShip is still running after $WorldShipExitTimeoutMinutes minutes."
    }

    Write-Log 'WorldShip exited normally.'
    Write-Log 'End of Day workflow completed. This script does not shut down Windows.'
    exit 0
}
catch {
    Write-Log ("FAILED: {0}" -f $_.Exception.Message)
    Write-Log 'Check WorldShip manually. This script never shuts down Windows.'
    exit 1
}
