﻿@echo off
chcp 65001 >nul
set "SCRIPT=%~dp0PrinterDiagnostic.ps1"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
echo.
pause

