﻿[CmdletBinding()]
param([string]$OutputFile)

$ErrorActionPreference = 'Stop'
if (-not $OutputFile) { $OutputFile = Join-Path $PSScriptRoot 'PrinterDiagnostic.exe' }
$sourceScript = Join-Path $PSScriptRoot 'PrinterDiagnostic.ps1'
if (-not (Test-Path -LiteralPath $sourceScript)) { throw "缺少來源檔：$sourceScript" }
$outputFull = [IO.Path]::GetFullPath($OutputFile)
$outputParent = Split-Path -Parent $outputFull
if (-not (Test-Path -LiteralPath $outputParent)) { New-Item -ItemType Directory -Path $outputParent -Force | Out-Null }
if (Test-Path -LiteralPath $outputFull) { Remove-Item -LiteralPath $outputFull -Force }

$payload = [Convert]::ToBase64String([IO.File]::ReadAllBytes($sourceScript))
$csharp = @"
using System;
using System.Diagnostics;
using System.IO;

public static class PrinterDiagnosticLauncher
{
    [STAThread]
    public static int Main()
    {
        string work = Path.Combine(Path.GetTempPath(), "PrinterDiagnostic-" + Guid.NewGuid().ToString("N"));
        string script = Path.Combine(work, "PrinterDiagnostic.ps1");
        try
        {
            Directory.CreateDirectory(work);
            File.WriteAllBytes(script, Convert.FromBase64String("$payload"));
            if (String.IsNullOrEmpty(Environment.GetEnvironmentVariable("PRINTER_DIAG_REPORT_DIR")))
                Environment.SetEnvironmentVariable("PRINTER_DIAG_REPORT_DIR", Path.Combine(Environment.CurrentDirectory, "Reports"));
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = "powershell.exe";
            info.Arguments = "-NoLogo -NoProfile -ExecutionPolicy Bypass -File \"" + script + "\"";
            info.UseShellExecute = false;
            Process child = Process.Start(info);
            child.WaitForExit();
            return child.ExitCode;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("無法啟動印表機診斷工具：" + ex.Message);
            Console.ReadKey();
            return 1;
        }
        finally
        {
            try { if (Directory.Exists(work)) Directory.Delete(work, true); } catch { }
        }
    }
}
"@

Add-Type -TypeDefinition $csharp -Language CSharp -OutputAssembly $outputFull -OutputType ConsoleApplication
$item = Get-Item -LiteralPath $outputFull
Write-Host ("封裝完成：{0}（{1:N0} bytes）" -f $item.FullName,$item.Length) -ForegroundColor Green
