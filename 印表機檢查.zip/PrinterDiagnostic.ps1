﻿[CmdletBinding()]
param(
    [ValidateSet('Interactive','Client','Host','Compare')]
    [string]$Mode = 'Interactive',
    [string]$PrinterPath,
    [string]$PeerReport,
    [string]$OutputDirectory = $(if ($env:PRINTER_DIAG_REPORT_DIR) { $env:PRINTER_DIAG_REPORT_DIR } else { Join-Path $PSScriptRoot 'Reports' })
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Write-Title([string]$Text) {
    Write-Host "`n=== $Text ===" -ForegroundColor Cyan
}

function Add-Check {
    param([string]$Name, [ValidateSet('PASS','WARN','FAIL','INFO')] [string]$Status,
          [string]$Detail, [string]$Side, [string]$Suggestion = '')
    $script:Checks.Add([pscustomobject]@{
        Name=$Name; Status=$Status; Detail=$Detail; Side=$Side; Suggestion=$Suggestion
    }) | Out-Null
    $color = @{PASS='Green'; WARN='Yellow'; FAIL='Red'; INFO='Gray'}[$Status]
    Write-Host ("[{0}] {1}: {2}" -f $Status,$Name,$Detail) -ForegroundColor $color
}

function Test-TcpPort([string]$Computer, [int]$Port, [int]$TimeoutMs = 1800) {
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $async = $client.BeginConnect($Computer,$Port,$null,$null)
        if (-not $async.AsyncWaitHandle.WaitOne($TimeoutMs,$false)) { return $false }
        $client.EndConnect($async); return $true
    } catch { return $false } finally { $client.Close() }
}

function Get-UncParts([string]$Path) {
    if ($Path -notmatch '^\\\\([^\\]+)\\([^\\]+)') { return $null }
    [pscustomobject]@{ Server=$Matches[1]; Share=$Matches[2]; Path="\\$($Matches[1])\$($Matches[2])" }
}

function Get-PrinterSafe {
    if (Get-Command Get-Printer -ErrorAction SilentlyContinue) {
        return @(Get-Printer -ErrorAction SilentlyContinue)
    }
    return @(Get-CimInstance Win32_Printer -ErrorAction SilentlyContinue)
}

function Test-CommonLocal([string]$Side) {
    Write-Title '本機基礎檢查'
    try { $osName = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).Caption }
    catch { $osName = [System.Environment]::OSVersion.VersionString }
    Add-Check '電腦資訊' INFO ("{0} / {1} / {2}" -f $env:COMPUTERNAME,$env:USERNAME,$osName) $Side

    $spooler = Get-Service Spooler -ErrorAction SilentlyContinue
    if (-not $spooler) {
        Add-Check 'Print Spooler' FAIL '找不到列印多工緩衝處理器服務' $Side '修復 Windows 列印元件。'
    } elseif ($spooler.Status -eq 'Running') {
        Add-Check 'Print Spooler' PASS '服務正在執行' $Side
    } else {
        Add-Check 'Print Spooler' FAIL ("服務狀態：{0}" -f $spooler.Status) $Side '以系統管理員身分啟動 Print Spooler。'
    }

    $printers = @(Get-PrinterSafe)
    Add-Check '已安裝印表機' INFO ("共 {0} 台" -f $printers.Count) $Side
    try {
        $jobs = @(Get-CimInstance Win32_PrintJob -ErrorAction Stop)
        if ($jobs.Count -gt 0) {
            $bad = @($jobs | Where-Object { $_.Status -match 'Error|Paused|Offline|Blocked' })
            $status = if ($bad.Count) {'WARN'} else {'INFO'}
            Add-Check '列印工作' $status ("佇列共 {0} 筆，異常 {1} 筆" -f $jobs.Count,$bad.Count) $Side '確認後再清除卡住的列印工作。'
        } else { Add-Check '列印工作' PASS '目前沒有卡住的工作' $Side }
    } catch { Add-Check '列印工作' WARN "無法讀取：$($_.Exception.Message)" $Side '嘗試以系統管理員身分執行。' }
}

function Invoke-ClientChecks([string]$Path) {
    $parts = Get-UncParts $Path
    if (-not $parts) { throw '印表機路徑格式錯誤，請使用 \\主機名稱\分享名稱。' }
    Test-CommonLocal 'Client'
    Write-Title '客戶端到共享主機'
    try {
        $addresses = [System.Net.Dns]::GetHostAddresses($parts.Server) | ForEach-Object IPAddressToString
        Add-Check 'DNS／名稱解析' PASS ("{0} → {1}" -f $parts.Server,($addresses -join ', ')) 'Network'
    } catch {
        Add-Check 'DNS／名稱解析' FAIL ("無法解析 {0}" -f $parts.Server) 'Network' '確認主機名稱、DNS；也可改用 \\IP\分享名稱測試。'
    }

    $ping = Test-Connection -ComputerName $parts.Server -Count 1 -Quiet -ErrorAction SilentlyContinue
    Add-Check 'Ping' $(if($ping){'PASS'}else{'WARN'}) $(if($ping){'主機有回應'}else{'無回應；可能只是 ICMP 被防火牆封鎖'}) 'Network'
    foreach ($port in @(445,135)) {
        $ok = Test-TcpPort $parts.Server $port
        $purpose = if ($port -eq 445) {'SMB 分享'} else {'RPC'}
        Add-Check "TCP $port ($purpose)" $(if($ok){'PASS'}else{'FAIL'}) $(if($ok){'連線成功'}else{'無法連線'}) 'Network' '檢查共享主機防火牆、網路區段與主機是否開機。'
    }

    try {
        $exists = Test-Path -LiteralPath $parts.Path -ErrorAction Stop
        Add-Check '印表機分享路徑' $(if($exists){'PASS'}else{'FAIL'}) $(if($exists){"可存取 $($parts.Path)"}else{"找不到或無權限存取 $($parts.Path)"}) 'Host' '到共享主機確認分享名稱與列印權限。'
    } catch {
        Add-Check '印表機分享路徑' FAIL $_.Exception.Message 'Host' '檢查認證、分享名稱及列印權限。'
    }

    $installed = @(Get-PrinterSafe | Where-Object {
        $_.Name -eq $Path -or $_.ConnectionName -eq $Path -or $_.PortName -like "*$($parts.Server)*"
    })
    if ($installed.Count) {
        $details = $installed | ForEach-Object { "{0}（狀態：{1}，驅動：{2}）" -f $_.Name,$_.PrinterStatus,$_.DriverName }
        Add-Check '客戶端印表機連線' PASS ($details -join '; ') 'Client'
    } else {
        Add-Check '客戶端印表機連線' WARN '本機未找到對應連線' 'Client' '若主機端正常，重新新增此共用印表機。'
    }
    return $parts
}

function Invoke-HostChecks([string]$Path) {
    Test-CommonLocal 'Host'
    Write-Title '共享主機端'
    $parts = if ($Path) { Get-UncParts $Path } else { $null }
    $printers = @(Get-PrinterSafe)
    $shared = @($printers | Where-Object { $_.Shared -eq $true -or $_.ShareName })
    if ($shared.Count) {
        Add-Check '共享印表機' PASS (($shared | ForEach-Object { "{0} → {1}" -f $_.Name,$_.ShareName }) -join '; ') 'Host'
    } else { Add-Check '共享印表機' FAIL '這台電腦沒有偵測到共享印表機' 'Host' '在印表機內容的「共用」頁籤啟用分享。' }

    if ($parts) {
        if ($parts.Server -notin @($env:COMPUTERNAME,'localhost','127.0.0.1','.')) {
            Add-Check '主機名稱核對' WARN ("路徑指定 {0}，目前電腦是 {1}" -f $parts.Server,$env:COMPUTERNAME) 'Host' '確認目前是在正確的共享主機執行。'
        } else { Add-Check '主機名稱核對' PASS '目前就是路徑指定的共享主機' 'Host' }
        $match = @($shared | Where-Object { $_.ShareName -eq $parts.Share })
        Add-Check '分享名稱核對' $(if($match){'PASS'}else{'FAIL'}) $(if($match){"找到分享 $($parts.Share)"}else{"找不到分享 $($parts.Share)"}) 'Host' '確認分享名稱沒有改動。'
    }

    foreach ($port in @(445,135)) {
        $ok = Test-TcpPort '127.0.0.1' $port
        Add-Check "本機 TCP $port" $(if($ok){'PASS'}else{'FAIL'}) $(if($ok){'服務有監聽'}else{'沒有服務監聽'}) 'Host' '檢查 Server、RPC 與 Print Spooler 服務。'
    }

    try {
        $fw = @(Get-NetFirewallRule -ErrorAction Stop | Where-Object {
            $_.DisplayGroup -match 'File and Printer Sharing|檔案及印表機共用' -and $_.Enabled -eq 'True'
        })
        Add-Check '防火牆分享規則' $(if($fw.Count){'PASS'}else{'WARN'}) $(if($fw.Count){"已啟用 $($fw.Count) 條相關規則"}else{'未偵測到啟用中的檔案及印表機共用規則'}) 'Host' '確認目前網路設定檔允許「檔案及印表機共用」。'
    } catch { Add-Check '防火牆分享規則' WARN '目前無法讀取防火牆規則' 'Host' '以系統管理員身分再次檢查。' }

    try {
        $events = @(Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-PrintService/Admin'; StartTime=(Get-Date).AddDays(-3)} -MaxEvents 30 -ErrorAction Stop |
            Where-Object LevelDisplayName -in @('Error','Warning','錯誤','警告'))
        Add-Check '近三日列印事件' $(if($events.Count){'WARN'}else{'PASS'}) $(if($events.Count){"找到 $($events.Count) 筆警告／錯誤"}else{'沒有警告或錯誤'}) 'Host' '至事件檢視器查看 PrintService/Admin 詳細錯誤碼。'
    } catch { Add-Check '近三日列印事件' INFO '事件記錄未啟用或無法讀取' 'Host' }
}

function Get-Verdict([object[]]$Items, [object[]]$PeerItems = @()) {
    $all = @($Items) + @($PeerItems)
    $hostFail = @($all | Where-Object { $_.Side -eq 'Host' -and $_.Status -eq 'FAIL' })
    $clientFail = @($all | Where-Object { $_.Side -eq 'Client' -and $_.Status -eq 'FAIL' })
    $networkFail = @($all | Where-Object { $_.Side -eq 'Network' -and $_.Status -eq 'FAIL' })
    if ($hostFail.Count) { return [pscustomobject]@{Category='共享主機端問題'; Confidence='高'; Reason=($hostFail.Detail -join '；')} }
    if ($networkFail.Count) { return [pscustomobject]@{Category='網路／共享主機防火牆問題'; Confidence='中高'; Reason=($networkFail.Detail -join '；')} }
    if ($clientFail.Count) { return [pscustomobject]@{Category='客戶端問題'; Confidence='高'; Reason=($clientFail.Detail -join '；')} }
    $clientWarn = @($all | Where-Object { $_.Side -eq 'Client' -and $_.Status -eq 'WARN' })
    if ($clientWarn.Count) { return [pscustomobject]@{Category='較可能是客戶端設定／驅動問題'; Confidence='中'; Reason=($clientWarn.Detail -join '；')} }
    return [pscustomobject]@{Category='未發現明確故障'; Confidence='低'; Reason='基礎檢查均通過，建議測試列印並查看錯誤碼或事件記錄。'}
}

function Read-Report([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { throw "找不到報告：$Path" }
    Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Save-Report([string]$RunMode, [string]$Path, [object]$Verdict, [object[]]$Items) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $base = Join-Path $OutputDirectory ("PrinterCheck-{0}-{1}-{2}" -f $env:COMPUTERNAME,$RunMode,$stamp)
    $report = [pscustomobject]@{
        SchemaVersion=1; Created=(Get-Date).ToString('o'); Computer=$env:COMPUTERNAME
        User=$env:USERNAME; Mode=$RunMode; PrinterPath=$Path; Verdict=$Verdict; Checks=$Items
    }
    $report | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$base.json" -Encoding UTF8
    $lines = @('共用印表機診斷報告',('='*60),"時間：$($report.Created)","電腦：$env:COMPUTERNAME", "模式：$RunMode", "路徑：$Path",'',
        "判斷：$($Verdict.Category)","信心：$($Verdict.Confidence)","原因：$($Verdict.Reason)",'', '檢查明細：')
    $lines += $Items | ForEach-Object { "[{0}] [{1}] {2}：{3}{4}" -f $_.Status,$_.Side,$_.Name,$_.Detail,$(if($_.Suggestion){"｜建議：$($_.Suggestion)"}else{''}) }
    $lines | Set-Content -LiteralPath "$base.txt" -Encoding UTF8
    Write-Title '診斷結論'
    Write-Host ("{0}（信心：{1}）" -f $Verdict.Category,$Verdict.Confidence) -ForegroundColor Magenta
    Write-Host $Verdict.Reason
    Write-Host "`n報告已儲存：`n$base.txt`n$base.json" -ForegroundColor Cyan
}

try {
    if ($Mode -eq 'Interactive') {
        Write-Host '共用印表機雙端診斷工具' -ForegroundColor Cyan
        Write-Host '1. 客戶端檢查  2. 共享主機端檢查  3. 比較兩份 JSON 報告'
        $choice = (Read-Host '請選擇 1/2/3').Trim()
        $Mode = @{'1'='Client';'2'='Host';'3'='Compare'}[$choice]
        if (-not $Mode) { throw '選項無效。' }
    }
    if ($Mode -in @('Client','Host') -and -not $PrinterPath) {
        $PrinterPath = Read-Host '請輸入共用印表機路徑（例如 \\PC01\HP-Laser；主機端可按 Enter 略過）'
    }
    $script:Checks = New-Object System.Collections.Generic.List[object]
    if ($Mode -eq 'Client') { $null = Invoke-ClientChecks $PrinterPath }
    elseif ($Mode -eq 'Host') { Invoke-HostChecks $PrinterPath }
    elseif ($Mode -eq 'Compare') {
        if (-not $PeerReport) { $PeerReport = Read-Host '第一份 JSON 報告路徑' }
        $second = Read-Host '第二份 JSON 報告路徑'
        $a = Read-Report $PeerReport; $b = Read-Report $second
        $items = @($a.Checks) + @($b.Checks)
        $verdict = Get-Verdict $items
        Save-Report 'Compare' ("{0} + {1}" -f $a.PrinterPath,$b.PrinterPath) $verdict $items
        exit 0
    }
    $peerItems = @()
    if ($PeerReport) { $peerItems = @((Read-Report $PeerReport).Checks) }
    # PowerShell 5.1 對 Generic.List 直接轉型成 object[] 有繫結問題，先走管線建立一般陣列。
    $currentItems = @($script:Checks | ForEach-Object { $_ })
    $verdict = Get-Verdict $currentItems $peerItems
    Save-Report $Mode $PrinterPath $verdict $currentItems
} catch {
    Write-Host "`n執行失敗：$($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
