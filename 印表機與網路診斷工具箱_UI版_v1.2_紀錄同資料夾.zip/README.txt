﻿印表機與網路診斷工具箱 UI v1.2
==================================

本版調整：
- 不再於桌面建立 Printer_Network_Toolbox_UI_Logs
- 不再建立以電腦名稱與日期命名的子資料夾
- 執行紀錄直接儲存在工具所在資料夾
- 紀錄檔名稱固定為 Toolbox_UI_Log.txt
- 每次啟動會在同一紀錄檔內加入分隔線與啟動時間
- CSV 匯出視窗預設開啟工具所在資料夾

資料夾範例：
Printer_Network_Toolbox_UI
├─ Run_Toolbox_UI.cmd
├─ Printer_Network_Toolbox_UI.ps1
├─ Toolbox_UI_Log.txt
└─ 使用者匯出的 CSV

使用方法：
1. 完整解壓縮。
2. 在 Run_Toolbox_UI.cmd 上按右鍵。
3. 選擇「以系統管理員身分執行」。

注意：
若工具放在無寫入權限的位置，例如 Program Files 或唯讀網路資料夾，
可能無法建立紀錄檔。建議放在 C:\Tools、桌面或隨身碟可寫入資料夾。
