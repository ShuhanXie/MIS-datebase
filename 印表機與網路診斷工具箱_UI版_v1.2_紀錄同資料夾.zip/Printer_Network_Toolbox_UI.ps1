﻿#requires -version 5.1
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()

$ErrorActionPreference = "Continue"
$ToolFolder = Split-Path -Parent $MyInvocation.MyCommand.Path
$SessionFolder = $ToolFolder
$LogPath = Join-Path $ToolFolder "Toolbox_UI_Log.txt"

function Write-Log {
    param([string]$Message)
    Add-Content -Path $LogPath -Value ("[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message) -Encoding UTF8
}

function Show-ErrorMessage {
    param([string]$Message)
    [System.Windows.Forms.MessageBox]::Show(
        $Message,
        "錯誤",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

function Show-InfoMessage {
    param([string]$Message)
    [System.Windows.Forms.MessageBox]::Show(
        $Message,
        "訊息",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Confirm-Action {
    param([string]$Message)
    $result = [System.Windows.Forms.MessageBox]::Show(
        $Message,
        "確認操作",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )
    return ($result -eq [System.Windows.Forms.DialogResult]::Yes)
}

function Add-UiLog {
    param([string]$Message)

    $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $Message
    Write-Log $Message

    if ($script:LogTextBox) {
        $script:LogTextBox.AppendText($line + [Environment]::NewLine)
        $script:LogTextBox.SelectionStart = $script:LogTextBox.TextLength
        $script:LogTextBox.ScrollToCaret()
        [System.Windows.Forms.Application]::DoEvents()
    }
}

function Set-GridData {
    param(
        [System.Windows.Forms.DataGridView]$Grid,
        [object[]]$Data
    )

    $Grid.SuspendLayout()
    try {
        $Grid.DataSource = $null
        $Grid.Rows.Clear()
        $Grid.Columns.Clear()

        $items = @($Data | Where-Object { $null -ne $_ })

        if ($items.Count -eq 0) {
            $emptyColumn = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
            $emptyColumn.Name = "結果"
            $emptyColumn.HeaderText = "結果"
            $emptyColumn.AutoSizeMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
            [void]$Grid.Columns.Add($emptyColumn)
            [void]$Grid.Rows.Add("沒有取得資料")
            return
        }

        $properties = @($items[0].PSObject.Properties.Name)

        foreach ($property in $properties) {
            $column = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
            $column.Name = [string]$property
            $column.HeaderText = [string]$property
            $column.SortMode = [System.Windows.Forms.DataGridViewColumnSortMode]::Automatic
            [void]$Grid.Columns.Add($column)
        }

        foreach ($item in $items) {
            $values = New-Object object[] $properties.Count

            for ($i = 0; $i -lt $properties.Count; $i++) {
                $value = $item.($properties[$i])

                if ($value -is [array]) {
                    $value = $value -join ", "
                }

                if ($null -eq $value) {
                    $value = ""
                }

                $values[$i] = [string]$value
            }

            [void]$Grid.Rows.Add($values)
        }

        $Grid.AutoResizeColumns([System.Windows.Forms.DataGridViewAutoSizeColumnsMode]::DisplayedCells)

        foreach ($column in $Grid.Columns) {
            if ($column.Width -gt 350) {
                $column.Width = 350
            }
            elseif ($column.Width -lt 90) {
                $column.Width = 90
            }
        }
    }
    finally {
        $Grid.ResumeLayout()
        $Grid.Refresh()
        [System.Windows.Forms.Application]::DoEvents()
    }
}

function Export-CurrentGrid {
    param([System.Windows.Forms.DataGridView]$Grid)

    if (-not $Grid.DataSource) {
        Show-InfoMessage "目前沒有可匯出的資料。"
        return
    }

    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Filter = "CSV 檔案 (*.csv)|*.csv"
    $dialog.InitialDirectory = $SessionFolder
    $dialog.FileName = "Export_{0}.csv" -f (Get-Date -Format "yyyyMMdd_HHmmss")

    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        try {
            $rows = @()
            foreach ($gridRow in $Grid.Rows) {
                if ($gridRow.IsNewRow) { continue }
                $obj = [ordered]@{}
                foreach ($column in $Grid.Columns) {
                    $obj[$column.HeaderText] = $gridRow.Cells[$column.Index].Value
                }
                $rows += [PSCustomObject]$obj
            }
            $rows | Export-Csv -Path $dialog.FileName -NoTypeInformation -Encoding UTF8
            Write-Log "匯出 CSV：$($dialog.FileName)"
            Show-InfoMessage "已匯出：`n$($dialog.FileName)"
        }
        catch {
            Show-ErrorMessage "匯出失敗：$($_.Exception.Message)"
        }
    }
}

function Test-TcpPort {
    param(
        [string]$Target,
        [int]$Port,
        [int]$TimeoutMs = 2500
    )

    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $async = $client.BeginConnect($Target, $Port, $null, $null)
        if (-not $async.AsyncWaitHandle.WaitOne($TimeoutMs, $false)) {
            throw "Timeout"
        }
        $client.EndConnect($async)
        return $true
    }
    catch {
        return $false
    }
    finally {
        $client.Close()
    }
}

function Get-NetworkData {
    $data = @()
    $configs = Get-CimInstance Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled }

    foreach ($cfg in $configs) {
        $adapter = Get-CimInstance Win32_NetworkAdapter |
            Where-Object { $_.Index -eq $cfg.Index } |
            Select-Object -First 1

        $data += [PSCustomObject]@{
            "網卡名稱" = $cfg.Description
            "連線名稱" = $adapter.NetConnectionID
            "MAC 位址" = $cfg.MACAddress
            "DHCP" = $cfg.DHCPEnabled
            "IP 位址" = (($cfg.IPAddress | Where-Object { $_ -match '^\d+\.' }) -join ", ")
            "子網路遮罩" = (($cfg.IPSubnet | Where-Object { $_ -match '^\d+\.' }) -join ", ")
            "預設閘道" = ($cfg.DefaultIPGateway -join ", ")
            "DNS" = ($cfg.DNSServerSearchOrder -join ", ")
            "DHCP 伺服器" = $cfg.DHCPServer
            "連線狀態" = switch ($adapter.NetConnectionStatus) {
                2 { "已連線" }
                7 { "媒體中斷" }
                default { "狀態碼 $($adapter.NetConnectionStatus)" }
            }
        }
    }
    return $data
}

function Get-PrinterData {
    return @(Get-CimInstance Win32_Printer | ForEach-Object {
        [PSCustomObject]@{
            "名稱" = $_.Name
            "驅動程式" = $_.DriverName
            "連接埠" = $_.PortName
            "預設印表機" = $_.Default
            "共用" = $_.Shared
            "共用名稱" = $_.ShareName
            "網路印表機" = $_.Network
            "離線模式" = $_.WorkOffline
            "狀態碼" = $_.PrinterStatus
        }
    })
}

function Get-PrinterPortData {
    $data = @()
    foreach ($port in (Get-CimInstance Win32_TCPIPPrinterPort)) {
        $ping = if ($port.HostAddress) {
            if (Test-Connection -ComputerName $port.HostAddress -Count 1 -Quiet -ErrorAction SilentlyContinue) {
                "成功"
            } else {
                "失敗"
            }
        } else {
            "未設定"
        }

        $portResult = if ($port.HostAddress -and $port.PortNumber) {
            if (Test-TcpPort -Target $port.HostAddress -Port $port.PortNumber) {
                "可連線"
            } else {
                "無回應"
            }
        } else {
            "未測試"
        }

        $data += [PSCustomObject]@{
            "連接埠名稱" = $port.Name
            "印表機 IP" = $port.HostAddress
            "Port" = $port.PortNumber
            "協定" = switch ($port.Protocol) {
                1 { "RAW" }
                2 { "LPR" }
                default { $port.Protocol }
            }
            "Queue" = $port.Queue
            "SNMP 啟用" = $port.SNMPEnabled
            "SNMP 社群" = $port.SNMPCommunity
            "Ping" = $ping
            "Port 測試" = $portResult
        }
    }
    return $data
}

function Get-PrintJobsData {
    return @(Get-CimInstance Win32_PrintJob | ForEach-Object {
        [PSCustomObject]@{
            "工作名稱" = $_.Name
            "文件名稱" = $_.Document
            "使用者" = $_.Owner
            "狀態" = $_.Status
            "工作狀態" = $_.JobStatus
            "總頁數" = $_.TotalPages
            "已列印頁數" = $_.PagesPrinted
            "提交時間" = $_.TimeSubmitted
        }
    })
}

function Run-NetworkTestData {
    $configs = Get-CimInstance Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled }
    $gateway = $configs.DefaultIPGateway | Where-Object { $_ } | Select-Object -First 1
    $dns = $configs.DNSServerSearchOrder | Where-Object { $_ } | Select-Object -First 1

    $targets = @(
        [PSCustomObject]@{ Name = "預設閘道"; Target = $gateway },
        [PSCustomObject]@{ Name = "DNS 伺服器"; Target = $dns },
        [PSCustomObject]@{ Name = "外部 IP"; Target = "1.1.1.1" },
        [PSCustomObject]@{ Name = "Google DNS"; Target = "8.8.8.8" }
    )

    $results = @()
    foreach ($item in $targets) {
        if (-not $item.Target) {
            $results += [PSCustomObject]@{
                "測試項目" = $item.Name
                "目標" = "未設定"
                "結果" = "無法測試"
                "平均延遲 ms" = ""
            }
            continue
        }

        $ping = Test-Connection -ComputerName $item.Target -Count 2 -ErrorAction SilentlyContinue
        $results += [PSCustomObject]@{
            "測試項目" = $item.Name
            "目標" = $item.Target
            "結果" = if ($ping) { "成功" } else { "失敗" }
            "平均延遲 ms" = if ($ping) {
                [math]::Round((($ping | Measure-Object ResponseTime -Average).Average), 1)
            } else {
                ""
            }
        }
    }

    try {
        $resolved = Resolve-DnsName "www.microsoft.com" -ErrorAction Stop |
            Where-Object { $_.IPAddress } |
            Select-Object -First 1

        $results += [PSCustomObject]@{
            "測試項目" = "DNS 名稱解析"
            "目標" = "www.microsoft.com"
            "結果" = "成功"
            "平均延遲 ms" = $resolved.IPAddress
        }
    }
    catch {
        $results += [PSCustomObject]@{
            "測試項目" = "DNS 名稱解析"
            "目標" = "www.microsoft.com"
            "結果" = "失敗"
            "平均延遲 ms" = $_.Exception.Message
        }
    }

    return $results
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "印表機與網路診斷工具箱 UI v1.2"
$form.Size = New-Object System.Drawing.Size(1200, 760)
$form.StartPosition = "CenterScreen"
$form.MinimumSize = New-Object System.Drawing.Size(960, 640)

$font = New-Object System.Drawing.Font("Microsoft JhengHei UI", 10)
$form.Font = $font

$topPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$topPanel.Dock = "Top"
$topPanel.Height = 92
$topPanel.Padding = New-Object System.Windows.Forms.Padding(10)
$topPanel.WrapContents = $true
$topPanel.AutoScroll = $true

$splitContainer = New-Object System.Windows.Forms.SplitContainer
$splitContainer.Dock = "Fill"
$splitContainer.Orientation = [System.Windows.Forms.Orientation]::Horizontal
$splitContainer.SplitterDistance = 470
$splitContainer.Panel1MinSize = 250
$splitContainer.Panel2MinSize = 90

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Dock = "Fill"
$grid.ReadOnly = $true
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.SelectionMode = "FullRowSelect"
$grid.MultiSelect = $false
$grid.AutoSizeRowsMode = "AllCells"
$grid.DefaultCellStyle.WrapMode = [System.Windows.Forms.DataGridViewTriState]::False
$grid.RowHeadersVisible = $false
$grid.BackgroundColor = [System.Drawing.Color]::White
$grid.BorderStyle = [System.Windows.Forms.BorderStyle]::Fixed3D
$grid.ColumnHeadersHeightSizeMode = [System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode]::AutoSize

$logPanel = New-Object System.Windows.Forms.Panel
$logPanel.Dock = "Fill"

$logLabel = New-Object System.Windows.Forms.Label
$logLabel.Text = "執行紀錄"
$logLabel.Dock = "Top"
$logLabel.Height = 24
$logLabel.Padding = New-Object System.Windows.Forms.Padding(6, 4, 0, 0)

$script:LogTextBox = New-Object System.Windows.Forms.TextBox
$script:LogTextBox.Dock = "Fill"
$script:LogTextBox.Multiline = $true
$script:LogTextBox.ReadOnly = $true
$script:LogTextBox.ScrollBars = "Vertical"
$script:LogTextBox.BackColor = [System.Drawing.Color]::White
$script:LogTextBox.Font = New-Object System.Drawing.Font("Consolas", 9)

$logPanel.Controls.Add($script:LogTextBox)
$logPanel.Controls.Add($logLabel)
$splitContainer.Panel1.Controls.Add($grid)
$splitContainer.Panel2.Controls.Add($logPanel)

$status = New-Object System.Windows.Forms.StatusStrip
$statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$statusLabel.Text = "就緒｜紀錄位置：$SessionFolder"
[void]$status.Items.Add($statusLabel)

function New-Button {
    param(
        [string]$Text,
        [scriptblock]$OnClick,
        [int]$Width = 150
    )

    $button = New-Object System.Windows.Forms.Button
    $button.Text = $Text
    $button.Width = $Width
    $button.Height = 34
    $button.Margin = New-Object System.Windows.Forms.Padding(4)
    $button.Add_Click($OnClick)
    return $button
}

$btnNetwork = New-Button "網路設定" {
    try {
        $statusLabel.Text = "正在讀取網路設定..."
        Add-UiLog "開始讀取網路設定"
        $form.Refresh()
        $data = @(Get-NetworkData)
        Set-GridData -Grid $grid -Data $data
        Add-UiLog "網路設定讀取完成，共 $($data.Count) 筆"
        $statusLabel.Text = "已顯示網路設定，共 $($data.Count) 筆"
    }
    catch {
        Show-ErrorMessage $_.Exception.Message
    }
}

$btnNetworkTest = New-Button "基本網路測試" {
    try {
        $statusLabel.Text = "正在執行網路測試..."
        Add-UiLog "開始執行基本網路測試"
        $form.Refresh()
        $data = @(Run-NetworkTestData)
        Set-GridData -Grid $grid -Data $data
        Add-UiLog "基本網路測試完成，共 $($data.Count) 筆"
        $statusLabel.Text = "網路測試完成"
    }
    catch {
        Show-ErrorMessage $_.Exception.Message
    }
}

$btnPrinters = New-Button "印表機清單" {
    try {
        $statusLabel.Text = "正在讀取印表機..."
        Add-UiLog "開始讀取印表機清單"
        $form.Refresh()
        $data = @(Get-PrinterData)
        Set-GridData -Grid $grid -Data $data
        Add-UiLog "印表機清單讀取完成，共 $($data.Count) 台"
        $statusLabel.Text = "已顯示印表機，共 $($data.Count) 台"
    }
    catch {
        Show-ErrorMessage $_.Exception.Message
    }
}

$btnPrinterPorts = New-Button "印表機 Port" {
    try {
        $statusLabel.Text = "正在測試印表機 Port..."
        Add-UiLog "開始檢測 TCP/IP 印表機 Port"
        $form.Refresh()
        $data = @(Get-PrinterPortData)
        Set-GridData -Grid $grid -Data $data
        Add-UiLog "印表機 Port 檢測完成，共 $($data.Count) 筆"
        $statusLabel.Text = "印表機 Port 檢測完成，共 $($data.Count) 筆"
    }
    catch {
        Show-ErrorMessage $_.Exception.Message
    }
}

$btnJobs = New-Button "列印佇列" {
    try {
        Add-UiLog "開始讀取列印佇列"
        $data = @(Get-PrintJobsData)
        Set-GridData -Grid $grid -Data $data
        Add-UiLog "列印佇列讀取完成，共 $($data.Count) 筆"
        $statusLabel.Text = if ($data.Count -eq 0) { "目前沒有列印工作" } else { "列印工作：$($data.Count) 筆" }
    }
    catch {
        Show-ErrorMessage $_.Exception.Message
    }
}

$btnPortTest = New-Button "自訂 Port 測試" {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "自訂 TCP Port 測試"
    $dialog.Size = New-Object System.Drawing.Size(430, 230)
    $dialog.StartPosition = "CenterParent"
    $dialog.Font = $font

    $lblTarget = New-Object System.Windows.Forms.Label
    $lblTarget.Text = "IP 或主機名稱："
    $lblTarget.Location = New-Object System.Drawing.Point(20, 25)
    $lblTarget.AutoSize = $true

    $txtTarget = New-Object System.Windows.Forms.TextBox
    $txtTarget.Location = New-Object System.Drawing.Point(145, 22)
    $txtTarget.Width = 235

    $lblPorts = New-Object System.Windows.Forms.Label
    $lblPorts.Text = "Port（逗號分隔）："
    $lblPorts.Location = New-Object System.Drawing.Point(20, 70)
    $lblPorts.AutoSize = $true

    $txtPorts = New-Object System.Windows.Forms.TextBox
    $txtPorts.Location = New-Object System.Drawing.Point(145, 67)
    $txtPorts.Width = 235
    $txtPorts.Text = "9100,445,3389,1433"

    $btnRun = New-Object System.Windows.Forms.Button
    $btnRun.Text = "開始測試"
    $btnRun.Location = New-Object System.Drawing.Point(145, 120)
    $btnRun.Width = 110

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "取消"
    $btnCancel.Location = New-Object System.Drawing.Point(270, 120)
    $btnCancel.Width = 110
    $btnCancel.Add_Click({ $dialog.Close() })

    $btnRun.Add_Click({
        $target = $txtTarget.Text.Trim()
        $ports = @()

        foreach ($entry in ($txtPorts.Text -split ",")) {
            $port = 0
            if ([int]::TryParse($entry.Trim(), [ref]$port) -and $port -ge 1 -and $port -le 65535) {
                $ports += $port
            }
        }

        if ([string]::IsNullOrWhiteSpace($target) -or $ports.Count -eq 0) {
            Show-ErrorMessage "請輸入有效的 IP／主機名稱與 Port。"
            return
        }

        $dialog.Close()
        $statusLabel.Text = "正在測試 $target..."
        Add-UiLog "開始測試 $target，Port：$($ports -join ', ')"
        $form.Refresh()

        $results = @()
        foreach ($port in $ports) {
            $results += [PSCustomObject]@{
                "目標" = $target
                "Port" = $port
                "結果" = if (Test-TcpPort -Target $target -Port $port) { "可連線" } else { "關閉、被擋或無回應" }
            }
        }

        Set-GridData -Grid $grid -Data $results
        Add-UiLog "自訂 Port 測試完成：$target"
        $statusLabel.Text = "Port 測試完成"
    })

    $dialog.Controls.AddRange(@($lblTarget, $txtTarget, $lblPorts, $txtPorts, $btnRun, $btnCancel))
    [void]$dialog.ShowDialog($form)
}

$btnRestartSpooler = New-Button "重啟 Spooler" {
    if (Confirm-Action "確定要重新啟動 Print Spooler 嗎？`n目前列印工作可能會受到影響。") {
        try {
            Restart-Service Spooler -Force -ErrorAction Stop
            Write-Log "重新啟動 Print Spooler"
            Show-InfoMessage "Print Spooler 已重新啟動。"
            $statusLabel.Text = "Print Spooler 已重新啟動"
        }
        catch {
            Show-ErrorMessage "重新啟動失敗：$($_.Exception.Message)"
        }
    }
}

$btnClearQueue = New-Button "清除列印佇列" {
    if (Confirm-Action "確定要清除所有尚未列印的工作嗎？`n此操作無法復原。") {
        try {
            Stop-Service Spooler -Force -ErrorAction Stop
            Start-Sleep -Seconds 2
            $spoolPath = Join-Path $env:SystemRoot "System32\spool\PRINTERS"
            Get-ChildItem -LiteralPath $spoolPath -Force -ErrorAction SilentlyContinue |
                Remove-Item -Force -ErrorAction Stop
            Start-Service Spooler -ErrorAction Stop
            Write-Log "清除列印佇列"
            Show-InfoMessage "列印佇列已清除。"
            $statusLabel.Text = "列印佇列已清除"
        }
        catch {
            try { Start-Service Spooler -ErrorAction SilentlyContinue } catch {}
            Show-ErrorMessage "清除失敗：$($_.Exception.Message)"
        }
    }
}

$btnFlushDns = New-Button "清除 DNS 快取" {
    if (Confirm-Action "確定要清除 DNS 快取嗎？") {
        try {
            ipconfig /flushdns | Out-Null
            Write-Log "清除 DNS 快取"
            Show-InfoMessage "DNS 快取已清除。"
            $statusLabel.Text = "DNS 快取已清除"
        }
        catch {
            Show-ErrorMessage $_.Exception.Message
        }
    }
}

$btnExport = New-Button "匯出目前表格" {
    Export-CurrentGrid -Grid $grid
}

$btnOpenFolder = New-Button "開啟紀錄資料夾" {
    Start-Process explorer.exe $SessionFolder
}

$topPanel.Controls.AddRange(@(
    $btnNetwork,
    $btnNetworkTest,
    $btnPrinters,
    $btnPrinterPorts,
    $btnJobs,
    $btnPortTest,
    $btnRestartSpooler,
    $btnClearQueue,
    $btnFlushDns,
    $btnExport,
    $btnOpenFolder
))

$form.Controls.Add($splitContainer)
$form.Controls.Add($topPanel)
$form.Controls.Add($status)

Add-Content -Path $LogPath -Value ("`r`n==================================================`r`n啟動時間：{0}`r`n電腦名稱：{1}`r`n==================================================" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $env:COMPUTERNAME) -Encoding UTF8
Add-UiLog "UI 工具箱已啟動，請點選上方功能按鈕"
[void]$form.ShowDialog()
Write-Log "UI 工具箱結束"
