@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Printer and Network Toolbox UI

pushd "%~dp0"
set "SCRIPT=%CD%\Printer_Network_Toolbox_UI.ps1"

if not exist "%SCRIPT%" (
    echo [ERROR] Cannot find Printer_Network_Toolbox_UI.ps1
    pause
    popd
    exit /b 2
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%SCRIPT%"
set "EXITCODE=%ERRORLEVEL%"

if not "%EXITCODE%"=="0" (
    echo.
    echo Tool exited with error code: %EXITCODE%
    pause
)

popd
exit /b %EXITCODE%
